#####################################################################################################################
#####################################################################################################################
################################## ZAM Shell created by Mohammed Zahid Wadiwale #####################################
## ZAM Language - Zahid Advanced Multirole Language is GUI Programming Language created by Mohammed Zahid Wadiwale ##
#####################################################################################################################
#####################################################################################################################
import os
import maker
os.system("title ZAM - Zahid Advanced Multirole Languange")
cmd = 'mode 125,30'
os.system(cmd)
print("*****************************************************************************************************************************")
print("*****************************************************************************************************************************")
print("************************************ ZAM Shell created by Mohammed Zahid Wadiwale *******************************************")
print("*****************************************************************************************************************************")
print("** ZAM Language - Zahid Advanced Multirole Language is GUI/Console Programming Language created by Mohammed Zahid Wadiwale **")
print("*****************************************************************************************************************************")
print("*****************************************************************************************************************************")
while True:
	ZM_code_command = input(' ZAM -PL -> ')
	if ZM_code_command.strip()=="":continue
	print("          "+ZM_code_command)
	result, error = maker.run('<stdin>' ,ZM_code_command)
	if error: print(error.as_string())
	elif result:
		if len(result.elements)==1:
			print("          "+repr(result.elements[0]))
		else:print("          "+repr(result))